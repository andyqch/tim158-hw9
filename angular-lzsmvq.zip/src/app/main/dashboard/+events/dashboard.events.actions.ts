import { Action } from '@ngrx/store';

export enum DashboardEventsActionTypes {
}

export type DashboardEventsActions =
  undefined;